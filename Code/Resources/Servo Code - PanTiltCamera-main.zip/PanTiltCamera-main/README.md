# PanTiltCamera
This repository contains code and diagram for pan tilt control using servo for esp32 camera
