code for ultrasoic sensor interface with esp32
